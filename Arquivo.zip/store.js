const money = n => new Intl.NumberFormat('pt-BR',{style:'currency',currency:'BRL'}).format(Number(n)||0);
async function loadStore(){
 const status=document.querySelector('#status'), grid=document.querySelector('#products');
 try{
  const r=await fetch('/api/products'); if(!r.ok) throw new Error('API indisponível');
  const data=await r.json(); const products=data.products||[];
  grid.innerHTML=products.map(p=>`<article class="product">${p.image?`<img src="${esc(p.image)}" alt="">`:''}<h3>${esc(p.name)}</h3><p>${esc(p.description||'')}</p><div class="price">${money(p.price)}</div><button class="button" onclick="alert('Para concluir a compra via Pix, copie a chave Pix abaixo e envie o comprovante ao vendedor.')">Comprar via Pix</button></article>`).join('');
  status.textContent=products.length?'Produtos disponíveis':'Ainda não há produtos cadastrados.';
  document.querySelector('#pix-key').textContent=data.pixKey||'A chave Pix será configurada pelo administrador.';
  window._pix=data.pixKey||'';
 }catch(e){status.textContent='A loja ainda não está conectada ao armazenamento compartilhado. Siga o arquivo LEIA-ME para concluir a configuração.';grid.innerHTML='';}
}
function esc(v){return String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
document.querySelector('#copy-pix').addEventListener('click',async()=>{if(!window._pix)return alert('O administrador ainda não configurou a chave Pix.');try{await navigator.clipboard.writeText(window._pix);alert('Chave Pix copiada!')}catch{alert('Não foi possível copiar automaticamente. Selecione e copie a chave exibida.')}});
loadStore();