-- Execute este SQL no painel D1 do Cloudflare, em zara-shop-db > Console.
CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT,email TEXT UNIQUE,pass TEXT,salt TEXT,role TEXT DEFAULT 'cliente',balance REAL DEFAULT 0,diamonds INTEGER DEFAULT 0,ref TEXT UNIQUE,refBy INTEGER,banned INTEGER DEFAULT 0,created TEXT);
CREATE TABLE IF NOT EXISTS products(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT,cat TEXT,price REAL,descr TEXT,images TEXT DEFAULT '[]',active INTEGER DEFAULT 1,owner INTEGER);
CREATE TABLE IF NOT EXISTS orders(id INTEGER PRIMARY KEY AUTOINCREMENT,user INTEGER,product INTEGER,pname TEXT,qty INTEGER,total REAL,playerId TEXT,status TEXT DEFAULT 'pendente',created TEXT);
CREATE TABLE IF NOT EXISTS deposits(id INTEGER PRIMARY KEY AUTOINCREMENT,user INTEGER,brl REAL,credit REAL,status TEXT DEFAULT 'pendente',note TEXT,created TEXT);
CREATE TABLE IF NOT EXISTS commissions(id INTEGER PRIMARY KEY AUTOINCREMENT,promoter INTEGER,orderId INTEGER,amount REAL,status TEXT DEFAULT 'pendente',created TEXT);
CREATE TABLE IF NOT EXISTS settings(k TEXT PRIMARY KEY,v TEXT);
CREATE TABLE IF NOT EXISTS spins(id INTEGER PRIMARY KEY AUTOINCREMENT,user INTEGER,prize TEXT,diamonds INTEGER,created TEXT);
CREATE TABLE IF NOT EXISTS feedback(id INTEGER PRIMARY KEY AUTOINCREMENT,user INTEGER,name TEXT,message TEXT,status TEXT DEFAULT 'novo',created TEXT);
INSERT OR IGNORE INTO settings(k,v) VALUES('store','ZARA SHOP TOPUP HAITIAN');
INSERT OR IGNORE INTO settings(k,v) VALUES('rate','25');
INSERT OR IGNORE INTO settings(k,v) VALUES('commission','5');
INSERT OR IGNORE INTO settings(k,v) VALUES('pix','');
INSERT OR IGNORE INTO settings(k,v) VALUES('wheel','[{"label":"5 diamantes","diamonds":5,"weight":40},{"label":"10 diamantes","diamonds":10,"weight":30},{"label":"20 diamantes","diamonds":20,"weight":18},{"label":"50 diamantes","diamonds":50,"weight":10},{"label":"100 diamantes","diamonds":100,"weight":2}]');
